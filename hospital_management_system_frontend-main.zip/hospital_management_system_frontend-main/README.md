# hospital_management_system_frontend

project create ( Kaung-Myat-Hun )

this project use following folder structure
```bash
|-- src ( project source directory )
    |-- Components ( project components directory )
    |-- Layout ( project layout directory )
    |-- Pages ( project pages directory )
    |-- Routes ( project routes directory )
    |-- services ( project services directory )
    |-- store ( Redux, Redux Toolkit directory )
```