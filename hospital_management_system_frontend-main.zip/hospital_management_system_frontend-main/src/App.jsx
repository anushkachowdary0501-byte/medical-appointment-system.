import './App.css'
import { View } from './Route/View'

function App() {

  return (
    <>
      <View/>
    </>
  )
}

export default App
