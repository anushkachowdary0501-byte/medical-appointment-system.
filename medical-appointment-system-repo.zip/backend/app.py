from flask import Flask, jsonify, request
app = Flask(__name__)

@app.route('/api/health', methods=['GET'])
def health():
    return jsonify({'status':'ok','service':'medical-backend'})

@app.route('/api/appointments', methods=['GET'])
def list_appointments():
    # placeholder data
    data = [
        {'id':1,'patient':'Alice','doctor':'Dr. Rao','time':'2025-11-10T10:00:00Z'},
        {'id':2,'patient':'Bob','doctor':'Dr. Singh','time':'2025-11-11T15:30:00Z'}
    ]
    return jsonify(data)

@app.route('/api/appointments', methods=['POST'])
def create_appointment():
    payload = request.json or {}
    # not persistent - placeholder
    return jsonify({'received': payload}), 201

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
