Ansible playbook notes
- The `deploy.yml` playbook builds local Docker images (does not push by default).
- To push to a registry, set `push: true` in the docker_image tasks and configure registry credentials.
- The playbook applies all manifests found in `k8s/`. Ensure `kubectl` is configured for the target cluster or use `kubeconfig` option.
