# Medical Appointment System - Kubernetes Deployment Repo

This repository is a scaffold for deploying a simple **Medical Appointment System** (fullstack placeholder) on **Kubernetes** using **Ansible** for orchestration, CI with GitHub Actions, and containerization with Docker.

**Contents**
- `frontend/` — simple static frontend served by Nginx (placeholder).
- `backend/` — minimal Flask backend (placeholder).
- `k8s/` — Kubernetes manifests (Namespace, Deployments, Services, HPA, Ingress example).
- `ansible/` — Ansible inventory and playbook to build images and deploy manifests.
- `.github/workflows/` — CI workflow example to build and push images.

> This scaffold is intentionally simple and meant as a starting point. Replace the placeholder app code with the real application linked by your assignment.

## How to use (local)
1. Build Docker images:
   - `docker build -t yourdockerhubuser/medical-backend:latest ./backend`
   - `docker build -t yourdockerhubuser/medical-frontend:latest ./frontend`
2. Push images to a registry (Docker Hub / GCR / ECR).
3. Update `k8s/` manifests image fields to point to your registry.
4. Apply manifests: `kubectl apply -f k8s/`
5. Or run the Ansible playbook (adjust inventory and variables): 
   `ansible-playbook -i ansible/inventory.ini ansible/deploy.yml`

## Files to customize
- `ansible/deploy.yml` — update registry, image names, and build/push steps.
- `k8s/` manifests — adjust resource requests/limits, ingress hostnames, and secrets.

