Kubernetes manifests
- Update the image fields in `backend-deployment.yaml` and `frontend-deployment.yaml` to point to your image registry.
- Apply the manifests with:
  kubectl apply -f namespace.yaml
  kubectl apply -f backend-deployment.yaml
  kubectl apply -f frontend-deployment.yaml
  kubectl apply -f hpa.yaml
  kubectl apply -f ingress-example.yaml
